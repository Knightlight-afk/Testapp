#!/usr/bin/env kotlin

data class WorkoutItem(
    val name: String,
    val sets: Int,
    val reps: Int
)