package com.example.trainova

import WorkoutViewModel
import android.graphics.Bitmap
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.util.Base64
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class HomeFragment : Fragment(), TextToSpeech.OnInitListener {

    // ── Change this to your laptop's IP address ──────────────────────────────
    private val API_BASE = "http://192.168.1.7:5000"
    // ─────────────────────────────────────────────────────────────────────────

    private val viewModel: WorkoutViewModel by activityViewModels()
    private lateinit var adapter: WorkoutAdapter
    private var selectedDay: String = ""

    private lateinit var tts: TextToSpeech
    private var ttsReady = false

    private val httpClient = OkHttpClient()
    private lateinit var cameraExecutor: ExecutorService
    private var imageAnalyzer: ImageAnalysis? = null
    private var lastApiCallTime = 0L
    private val API_INTERVAL_MS = 500L  // call API every 500ms

    private var tvFeedback: TextView? = null
    private var tvReps: TextView? = null
    private var sessionCounter: TextView? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        tts = TextToSpeech(requireContext(), this)
        cameraExecutor = Executors.newSingleThreadExecutor()

        val sdf = SimpleDateFormat("EEEE", Locale.getDefault())
        selectedDay = sdf.format(Date())

        val rvProgram      = view.findViewById<RecyclerView>(R.id.rvWorkoutProgram)
        val btnStart       = view.findViewById<Button>(R.id.btnStartProgram)
        val btnEnd         = view.findViewById<Button>(R.id.btnEndSession)
        val programLayout  = view.findViewById<View>(R.id.programLayout)
        val calendarHeader = view.findViewById<View>(R.id.calendarHeader)
        val viewFinder     = view.findViewById<PreviewView>(R.id.viewFinder)
        val feedbackCard   = view.findViewById<CardView>(R.id.feedbackCard)
        sessionCounter     = view.findViewById<TextView>(R.id.sessionCounter)
        tvFeedback         = view.findViewById<TextView>(R.id.statusText)
        tvReps             = view.findViewById<TextView>(R.id.repCountText)

        adapter = WorkoutAdapter(mutableListOf()) { item -> viewModel.removeExercise(item) }
        rvProgram.layoutManager = LinearLayoutManager(requireContext())
        rvProgram.adapter = adapter

        val dayMap = mapOf(
            "Monday"    to view.findViewById<LinearLayout>(R.id.dayMon),
            "Tuesday"   to view.findViewById<LinearLayout>(R.id.dayTue),
            "Wednesday" to view.findViewById<LinearLayout>(R.id.dayWed),
            "Thursday"  to view.findViewById<LinearLayout>(R.id.dayThu),
            "Friday"    to view.findViewById<LinearLayout>(R.id.dayFri),
            "Saturday"  to view.findViewById<LinearLayout>(R.id.daySat),
            "Sunday"    to view.findViewById<LinearLayout>(R.id.daySun)
        )

        dayMap.forEach { (name, layout) ->
            layout?.setOnClickListener {
                selectedDay = name
                updateCalendarSelectionUI(dayMap)
                refreshDailyList(view)
            }
        }

        viewModel.workoutProgram.observe(viewLifecycleOwner) {
            refreshDailyList(view)
            updateCalendarSelectionUI(dayMap)
        }

        btnStart.setOnClickListener {
            programLayout.visibility  = View.GONE
            calendarHeader.visibility = View.GONE
            btnStart.visibility       = View.GONE
            viewFinder.visibility     = View.VISIBLE
            feedbackCard.visibility   = View.VISIBLE
            btnEnd.visibility         = View.VISIBLE
            sessionCounter?.visibility = View.VISIBLE

            resetServerReps()
            startCamera(viewFinder)
            speak("Session started. Let's go!")
        }

        btnEnd.setOnClickListener {
            stopCamera()
            programLayout.visibility  = View.VISIBLE
            calendarHeader.visibility = View.VISIBLE
            btnStart.visibility       = View.VISIBLE
            viewFinder.visibility     = View.GONE
            feedbackCard.visibility   = View.GONE
            btnEnd.visibility         = View.GONE
            sessionCounter?.visibility = View.GONE
            speak("Session complete. Great work!")
        }
    }

    // ── Camera ────────────────────────────────────────────────────────────────

    private fun startCamera(viewFinder: PreviewView) {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(requireContext())
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder().build()
                .also { it.setSurfaceProvider(viewFinder.surfaceProvider) }

            imageAnalyzer = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also { analysis ->
                    analysis.setAnalyzer(cameraExecutor) { imageProxy ->
                        processFrame(imageProxy)
                    }
                }

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    viewLifecycleOwner,
                    CameraSelector.DEFAULT_BACK_CAMERA,
                    preview,
                    imageAnalyzer
                )
            } catch (e: Exception) {
                Log.e("Trainova", "Camera error", e)
            }
        }, ContextCompat.getMainExecutor(requireContext()))
    }

    private fun stopCamera() {
        val future = ProcessCameraProvider.getInstance(requireContext())
        future.addListener({ future.get().unbindAll() }, ContextCompat.getMainExecutor(requireContext()))
    }

    // ── Frame → API ───────────────────────────────────────────────────────────

    private fun processFrame(imageProxy: ImageProxy) {
        val now = System.currentTimeMillis()
        if (now - lastApiCallTime < API_INTERVAL_MS) {
            imageProxy.close()
            return
        }
        lastApiCallTime = now

        val bitmap = imageProxy.toBitmap()
        imageProxy.close()

        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 60, stream)
        val base64Frame = Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)

        val json = JSONObject().put("frame", base64Frame).toString()
        val body = json.toRequestBody("application/json".toMediaType())
        val request = Request.Builder().url("$API_BASE/predict").post(body).build()

        httpClient.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e("Trainova", "API call failed: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                val responseBody = response.body?.string() ?: return
                val json = JSONObject(responseBody)
                handleApiResponse(json)
            }
        })
    }

    private fun handleApiResponse(json: JSONObject) {
        val status = json.optString("status")
        if (status == "no_pose") return

        val form  = json.optString("form", "")
        val reps  = json.optInt("reps", 0)
        val coach = json.optString("coach", "")

        requireActivity().runOnUiThread {
            tvFeedback?.text = form
            tvFeedback?.setTextColor(
                if (form == "Good")
                    ContextCompat.getColor(requireContext(), android.R.color.holo_green_light)
                else
                    ContextCompat.getColor(requireContext(), android.R.color.holo_red_light)
            )
            tvReps?.text = "$reps"
            sessionCounter?.text = "$reps"
        }

        if (coach.isNotEmpty()) speak(coach)
    }

    // ── Voice coaching ────────────────────────────────────────────────────────

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale.US
            ttsReady = true
        }
    }

    private fun speak(text: String) {
        if (ttsReady) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null)
    }

    // ── Server helpers ────────────────────────────────────────────────────────

    private fun resetServerReps() {
        val request = Request.Builder()
            .url("$API_BASE/reset")
            .post("{}".toRequestBody("application/json".toMediaType()))
            .build()
        httpClient.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {}
            override fun onResponse(call: Call, response: Response) { response.close() }
        })
    }

    // ── Workout list helpers ──────────────────────────────────────────────────

    private fun refreshDailyList(rootView: View) {
        val fullList     = viewModel.workoutProgram.value ?: listOf()
        val filteredList = fullList.filter { it.selectedDays.contains(selectedDay) }
        adapter.updateList(filteredList)

        rootView.findViewById<TextView>(R.id.dailyProgramTitle)?.text = "My $selectedDay Program"
        val btnStart = rootView.findViewById<Button>(R.id.btnStartProgram)
        btnStart.isEnabled = filteredList.isNotEmpty()
        btnStart.text = if (filteredList.isEmpty()) "No Exercises Scheduled" else "START $selectedDay SESSION"
    }

    private fun updateCalendarSelectionUI(dayMap: Map<String, LinearLayout?>) {
        dayMap.forEach { (name, layout) ->
            layout?.setBackgroundResource(if (name == selectedDay) R.drawable.selected_day_bg else 0)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
        tts.stop()
        tts.shutdown()
    }
}
