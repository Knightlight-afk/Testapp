package com.example.trainova

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
// REMOVE: import com.example.trainova.R.*
class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Using R.layout instead of just 'layout'
        setContentView(R.layout.activity_login)

        // Using R.id instead of just 'id'
        val btnGoogle = findViewById<CardView>(R.id.btnGoogleSignIn)

        // 3. Null check to prevent "Aborting session" if ID is not found
        if (btnGoogle == null) {
            Toast.makeText(this, "Error: Login button not found!", Toast.LENGTH_LONG).show()
            return
        }

        btnGoogle.setOnClickListener {
            Toast.makeText(this, "Signing in with Google...", Toast.LENGTH_SHORT).show()

            // Intent to move from Login to Main
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)

            // finish() is good—it removes Login from the backstack
            finish()
        }
    }
}