package com.example.trainova

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import com.google.android.material.switchmaterial.SwitchMaterial

class ProfileFragment : Fragment() {

    // 1. Register the Photo Picker Launcher
    private val pickMedia = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            // This runs when the user selects an image
            val imgProfile = view?.findViewById<ImageView>(R.id.imgProfile)
            imgProfile?.setImageURI(uri)

            // Removing padding ensures the photo fills the circle
            imgProfile?.setPadding(0, 0, 0, 0)

            Toast.makeText(requireContext(), "Profile picture updated!", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_profile, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Find the UI elements
        val profileCard = view.findViewById<View>(R.id.profileImageCard)
        val imgProfile = view.findViewById<ImageView>(R.id.imgProfile)
        val switchVoice = view.findViewById<SwitchMaterial>(R.id.switchVoice)
        val btnEditProfile = view.findViewById<TextView>(R.id.btnEditProfile)
        val btnLogout = view.findViewById<TextView>(R.id.btnLogout)
        val txtName = view.findViewById<TextView>(R.id.txtName)

        txtName.text = "Trainova Athlete"

        // 2. Handle Profile Picture Click
        profileCard?.setOnClickListener {
            // Launches the Android Photo Picker
            pickMedia.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }

        // 3. Voice Coaching Switch
        switchVoice?.setOnCheckedChangeListener { _, isChecked ->
            val status = if (isChecked) "Enabled" else "Disabled"
            Toast.makeText(requireContext(), "Voice Coaching $status", Toast.LENGTH_SHORT).show()
        }

        // 4. Edit Metrics
        btnEditProfile?.setOnClickListener {
            Toast.makeText(requireContext(), "Opening Metrics Editor...", Toast.LENGTH_SHORT).show()
        }

        // 5. Logout
        btnLogout?.setOnClickListener {
            Toast.makeText(requireContext(), "Logging out...", Toast.LENGTH_SHORT).show()
        }
    }
}