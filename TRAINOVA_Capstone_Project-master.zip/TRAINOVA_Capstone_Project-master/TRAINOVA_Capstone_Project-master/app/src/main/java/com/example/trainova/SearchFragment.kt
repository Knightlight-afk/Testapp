package com.example.trainova

import WorkoutViewModel
import android.app.AlertDialog
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import android.widget.ToggleButton
import androidx.fragment.app.activityViewModels

class SearchFragment : Fragment() {

    private val viewModel: WorkoutViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_search, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Updated Exercise List
        setupExerciseCard(view, R.id.bench_press_card, "Bench Press")
        setupExerciseCard(view, R.id.barbell_row_card, "Barbell Row")
        setupExerciseCard(view, R.id.deadlift_card, "Deadlift")
        setupExerciseCard(view, R.id.triceps_pushdown_card, "Triceps Pushdown")
        setupExerciseCard(view, R.id.biceps_curl_card, "Biceps Curl")
        setupExerciseCard(view, R.id.squat_card, "Squat")
        setupExerciseCard(view, R.id.rdl_card, "RDL")
        setupExerciseCard(view, R.id.pushup_card, "Push up")

        val btnStart = view.findViewById<Button>(R.id.btn_start_workout)
        btnStart.setOnClickListener {
            val currentProgram = viewModel.workoutProgram.value
            if (!currentProgram.isNullOrEmpty()) {
                Toast.makeText(context, "Check your Home tab for today's plan!", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(context, "Please add exercises first!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setupExerciseCard(rootView: View, cardId: Int, exerciseName: String) {
        rootView.findViewById<View>(cardId)?.setOnClickListener {
            showAddExerciseDialog(exerciseName)
        }
    }

    private fun showAddExerciseDialog(exerciseName: String) {
        // 1. Use the custom theme to remove gray borders
        val builder = AlertDialog.Builder(requireContext(), R.style.TrainovaDialog)
        val dialogView = layoutInflater.inflate(R.layout.dialog_add_exercise, null)
        builder.setView(dialogView)

        val dialog = builder.create()

        // 2. Setup UI references from XML
        val tvSets = dialogView.findViewById<TextView>(R.id.tvSetsValue)
        val tvReps = dialogView.findViewById<TextView>(R.id.tvRepsValue)
        val tvTitle = dialogView.findViewById<TextView>(R.id.dialogTitle) // Make sure this ID is in your XML

        tvTitle?.text = "Schedule $exerciseName"

        var currentSets = 3
        var currentReps = 12

        val dayToggles = mapOf(
            "Monday" to dialogView.findViewById<ToggleButton>(R.id.toggleMon),
            "Tuesday" to dialogView.findViewById<ToggleButton>(R.id.toggleTue),
            "Wednesday" to dialogView.findViewById<ToggleButton>(R.id.toggleWed),
            "Thursday" to dialogView.findViewById<ToggleButton>(R.id.toggleThu),
            "Friday" to dialogView.findViewById<ToggleButton>(R.id.toggleFri),
            "Saturday" to dialogView.findViewById<ToggleButton>(R.id.toggleSat),
            "Sunday" to dialogView.findViewById<ToggleButton>(R.id.toggleSun)
        )

        // 3. Logic for Plus/Minus Buttons
        dialogView.findViewById<Button>(R.id.btnPlusSets).setOnClickListener { currentSets++; tvSets.text = currentSets.toString() }
        dialogView.findViewById<Button>(R.id.btnMinusSets).setOnClickListener { if (currentSets > 1) { currentSets--; tvSets.text = currentSets.toString() } }
        dialogView.findViewById<Button>(R.id.btnPlusReps).setOnClickListener { currentReps++; tvReps.text = currentReps.toString() }
        dialogView.findViewById<Button>(R.id.btnMinusReps).setOnClickListener { if (currentReps > 1) { currentReps--; tvReps.text = currentReps.toString() } }

        // 4. Custom Footer Button Logic (Removes the Gray Part)
        dialogView.findViewById<Button>(R.id.btnCancel).setOnClickListener {
            dialog.dismiss()
        }

        dialogView.findViewById<Button>(R.id.btnAddProgram).setOnClickListener {
            val selectedDays = dayToggles.filter { it.value?.isChecked == true }.keys.toList()

            if (selectedDays.isEmpty()) {
                Toast.makeText(requireContext(), "Please select at least one day!", Toast.LENGTH_SHORT).show()
            } else {
                val item = WorkoutItem(exerciseName, currentSets, currentReps, selectedDays)
                viewModel.addExercise(item)
                Toast.makeText(requireContext(), "Saved for ${selectedDays.joinToString(", ")}", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
        }

        dialog.show()

        val window = dialog.window
        window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.95).toInt(), // 95% of screen width
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }
}