package com.example.trainova

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.components.XAxis
import androidx.core.graphics.toColorInt

class StatsFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_stats, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // 1. Find the Charts in your XML
        val barChart = view.findViewById<BarChart>(R.id.volumeBarChart)
        val lineChart = view.findViewById<LineChart>(R.id.precisionLineChart)

        // 2. Setup the Charts with Static Data
        setupVolumeChart(barChart)
        setupPrecisionChart(lineChart)
    }

    private fun setupVolumeChart(chart: BarChart?) {
        if (chart == null) return

        val entries = ArrayList<BarEntry>()
        entries.add(BarEntry(0f, 40f)) // Squats
        entries.add(BarEntry(1f, 25f)) // Pushups
        entries.add(BarEntry(2f, 15f)) // Lunges

        val dataSet = BarDataSet(entries, "Total Reps")
        dataSet.color = "#0077B6".toColorInt() // Trainova Blue
        dataSet.valueTextColor = Color.WHITE
        dataSet.valueTextSize = 12f

        chart.data = BarData(dataSet)

        // Styling for Dark Theme
        chart.description.isEnabled = false
        chart.xAxis.textColor = Color.WHITE
        chart.xAxis.position = XAxis.XAxisPosition.BOTTOM
        chart.axisLeft.textColor = Color.WHITE
        chart.axisRight.isEnabled = false
        chart.legend.textColor = Color.WHITE
        chart.animateY(1000) // Cool animation for documentation demo
        chart.invalidate()
    }

    private fun setupPrecisionChart(chart: LineChart?) {
        if (chart == null) return

        val entries = ArrayList<Entry>()
        entries.add(Entry(1f, 95f)) // Set 1
        entries.add(Entry(2f, 92f)) // Set 2
        entries.add(Entry(3f, 85f)) // Set 3 (Fatigue sets in)
        entries.add(Entry(4f, 78f)) // Set 4

        val dataSet = LineDataSet(entries, "Form Accuracy %")
        dataSet.color = Color.parseColor("#2D6A4F") // Forest Green
        dataSet.setCircleColor(Color.WHITE)
        dataSet.lineWidth = 3f
        dataSet.valueTextColor = Color.WHITE
        dataSet.mode = LineDataSet.Mode.CUBIC_BEZIER // Makes the line smooth

        chart.data = LineData(dataSet)

        // Styling for Dark Theme
        chart.description.isEnabled = false
        chart.xAxis.textColor = Color.WHITE
        chart.axisLeft.textColor = Color.WHITE
        chart.axisRight.isEnabled = false
        chart.legend.textColor = Color.WHITE
        chart.animateX(1000)
        chart.invalidate()
    }
}