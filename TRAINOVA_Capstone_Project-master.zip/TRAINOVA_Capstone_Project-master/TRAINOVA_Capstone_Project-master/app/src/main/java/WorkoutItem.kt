package com.example.trainova

data class WorkoutItem(
    val name: String,
    val sets: Int,
    val reps: Int,
    val selectedDays: List<String> = listOf() // This fixes the "Too many arguments" error
)