import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.trainova.WorkoutItem

class WorkoutViewModel : ViewModel() {
    // This list holds the user's current program
    val workoutProgram = MutableLiveData<MutableList<WorkoutItem>>(mutableListOf())

    fun addExercise(item: WorkoutItem) {
        val currentList = workoutProgram.value ?: mutableListOf()
        currentList.add(item)
        workoutProgram.value = currentList
    }

    fun removeExercise(item: WorkoutItem) {
        val currentList = workoutProgram.value ?: mutableListOf()
        currentList.remove(item)
        workoutProgram.value = currentList
    }
}